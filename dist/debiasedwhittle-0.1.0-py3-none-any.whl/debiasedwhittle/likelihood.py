import warnings
import numpy as np
from numpy.fft import fftn
from scipy.optimize import fmin_l_bfgs_b
from .expected_periodogram import compute_ep


def prod_list(l):
    if len(l) == 0:
        return 1
    else:
        return l[0] * prod_list(l[1:])


def shape_two(shape):
    new_shape = []
    for e in shape:
        new_shape.append(2 * e)
    return tuple(new_shape)


def periodogram(y, grid=None, fold=True):
    shape = y.shape
    if grid is None:
        n = prod_list(shape)
    else:
        n = np.sum(grid**2)
    if not fold:
        shape = shape_two(shape)
    return 1 / n * abs(fftn(y, shape))**2


def whittle(per, e_per):
    n = prod_list(per.shape)
    return 1 / n * np.sum(np.log(e_per) + per / e_per)


def fit(y, grid, cov_func, init_guess, fold=True):
    per = periodogram(y, grid, fold=fold)

    def opt_func(x):
        e_per = compute_ep(lambda lags: cov_func(lags, *x), grid, fold=fold)
        return whittle(per, e_per)

    est_, fval, info = fmin_l_bfgs_b(lambda x: opt_func(x * init_guess),
                                     np.ones_like(init_guess),
                                     maxiter=100,
                                     approx_grad=True,
                                     bounds=[(0.01, 100), ] * len(init_guess))
                                     #bounds=[(0.01, 100), (0.1, 5), (0.1, 10.)])
                                     #bounds=[(0.1, 1000), (0.1, 1000), (-np.pi, np.pi)])

    if info['warnflag'] != 0:
        warnings.warn('Issue during optimization')

    return est_ * init_guess