import numpy as np
from numpy.fft import fftn, ifftn
import warnings
from .expected_periodogram import autocov
from typing import List

def prod_list(l: List[int]):
    l = list(l)
    if l == []:
        return 1
    else:
        return l[0] * prod_list(l[1:])

#TODO make this work for 1-d and 3-d
def sim_circ_embedding(cov_func, shape):
    cov = autocov(cov_func, shape)
    f = np.real(2 ** len(shape) * prod_list(shape) * fftn(cov))
    min_ = np.min(f)
    if min_ <= 0:
        warnings.warn(f'Embedding is not positive definite, min value {min_}.')
    e = (np.random.randn(*f.shape) + 1j * np.random.randn(*f.shape))
    z = np.sqrt(np.maximum(f, 0)) * e
    z_inv = np.real(ifftn(z))
    for i, n in enumerate(shape):
        z_inv = np.take(z_inv, np.arange(n), i)
    return z_inv, min_
